# electron-adb-file

**An ADB file tool built on Electron.**

This is a not-finished documentation.

## License

[GPL 2.0](LICENSE)
