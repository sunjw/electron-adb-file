# electron-adb-file

**An ADB file tool built on Electron.**

This is a not-finished documentation.

## Build and run
1. npm install
2. npm rebuild
3. npm run rebuild-node-pty
4. If no error occured in previous steps, then run.

## License

[GPL 2.0](LICENSE)
